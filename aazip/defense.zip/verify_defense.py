"""Defense layer test: each knob does something measurable and composes."""
import sys
sys.path.insert(0, "/home/claude/deadline-tiered-fl/src")
import numpy as np
from dtfl.defense import (
    DefenseConfig, BucketMode, CountMode,
    apply_count_defense, merge_weight_for,
    apply_send_delay, apply_padding,
    deadline_quantiles_for, bucketer_for,
)
from dtfl.types import RoundDeadlines

passed = failed = 0
def check(name, cond, detail=""):
    global passed, failed
    if cond: print(f"  PASS  {name}"); passed += 1
    else: print(f"  FAIL  {name}  {detail}"); failed += 1

rng = np.random.default_rng(0)

# --- 1. count defenses ---
exact = DefenseConfig(count_mode=CountMode.EXACT)
check("EXACT reveals true count", apply_count_defense(57, exact, rng)==57)
hidden = DefenseConfig(count_mode=CountMode.HIDDEN)
check("HIDDEN reveals None", apply_count_defense(57, hidden, rng) is None)
rounded = DefenseConfig(count_mode=CountMode.ROUNDED, count_round_to=10)
check("ROUNDED rounds to multiple", apply_count_defense(57, rounded, rng)==60)
noised = DefenseConfig(count_mode=CountMode.NOISED, count_noise_scale=5.0)
samples = [apply_count_defense(100, noised, rng) for _ in range(1000)]
check("NOISED centered near true", abs(np.mean(samples)-100) < 2, f"mean={np.mean(samples):.1f}")
check("NOISED has spread", np.std(samples) > 2, f"std={np.std(samples):.1f}")
check("NOISED stays nonnegative", min(samples) >= 0)

# --- 2. merge-weight coupling (privacy -> utility bias) ---
# Hidden count: server falls back to weight 1 (max bias).
check("hidden count -> weight 1 (trust)", merge_weight_for(57, None, trust_revealed=True)==1)
check("hidden count -> true weight (no trust)", merge_weight_for(57, None, trust_revealed=False)==57)
# Rounded count: weight is the rounded value when trusted.
check("rounded count -> rounded weight (trust)", merge_weight_for(57, 60, trust_revealed=True)==60)
# This gap (57 vs 60) is the merge bias the experiment measures.

# --- 3. send delay only delays, never speeds up ---
tau = np.array([1.0, 2.0, 3.0, 4.0])
cutoffs = np.array([1.5, 2.5, 5.0])
jit_cfg = DefenseConfig(send_delay_scale=0.3)
jittered = apply_send_delay(tau, cutoffs, jit_cfg, rng)
check("jitter never speeds up", np.all(jittered >= tau))
check("jitter actually moves some", np.any(jittered > tau))
off_cfg = DefenseConfig(send_delay_scale=0.0)
check("jitter off is no-op", np.array_equal(apply_send_delay(tau, cutoffs, off_cfg, rng), tau))

# --- 4. padding inflates toward target ---
pad = apply_padding(true_active_count=20, padding_target=50)
check("padding raises count to target", pad.revealed_count==50 and pad.num_dummies==30)
nopad = apply_padding(true_active_count=80, padding_target=50)
check("padding no-op when above target", nopad.revealed_count==80 and nopad.num_dummies==0)
off = apply_padding(true_active_count=20, padding_target=0)
check("padding disabled", off.num_dummies==0)

# --- 5. adapters: deadline quantiles + bucketer ---
cfg3 = DefenseConfig(num_tiers=3)
check("3 tiers -> 2 interior quantiles", deadline_quantiles_for(cfg3)==(1/3, 2/3))
cfg8 = DefenseConfig(num_tiers=8)
check("8 tiers -> 7 interior quantiles", len(deadline_quantiles_for(cfg8))==7)

deadlines = RoundDeadlines(0, (1.0, 2.0, 3.0))
b_single = bucketer_for(DefenseConfig(bucket_mode=BucketMode.SINGLE), round_budget=3.0)
check("SINGLE bucketer -> always 0", b_single(0.5, deadlines)==0 and b_single(2.9, deadlines)==0)
b_uniform = bucketer_for(DefenseConfig(bucket_mode=BucketMode.UNIFORM, num_buckets=6), round_budget=3.0)
check("UNIFORM bucketer -> resolution", b_uniform(0.25, deadlines)==0 and b_uniform(2.9, deadlines)==5)
b_tier = bucketer_for(DefenseConfig(bucket_mode=BucketMode.PER_TIER), round_budget=3.0)
check("PER_TIER bucketer", b_tier(1.5, deadlines)==1)

# --- 6. undefended detection ---
check("default config is undefended", DefenseConfig().is_undefended)
check("m_min=64 is defended", not DefenseConfig(m_min=64).is_undefended)
check("single-bucket is defended", not DefenseConfig(bucket_mode=BucketMode.SINGLE).is_undefended)

print(f"\n{passed} passed, {failed} failed")
sys.exit(1 if failed else 0)
