"""End-to-end protocol test: tiering -> dropout -> threshold -> release -> merge,
plus the FedAvg-equivalence theorem and the t<=m_min invariant."""
import sys
sys.path.insert(0, "/home/claude/deadline-tiered-fl/src")
import numpy as np
from dtfl.rng import RngHub
from dtfl.latent import LatentConfig, build_population, draw_completion_times
from dtfl.types import RoundDeadlines
from dtfl.protocol import (
    assign_tiers, tier_rosters, MISSED,
    DropoutRates, apply_dropout,
    reconstruction_threshold, safe_coupling_holds,
    decide_release, emit_record,
    TierContribution, size_weighted_merge, weighted_merge, apply_server_update,
)

passed = failed = 0
def check(name, cond, detail=""):
    global passed, failed
    if cond: print(f"  PASS  {name}"); passed += 1
    else: print(f"  FAIL  {name}  {detail}"); failed += 1

hub = RngHub(seed=2024)
cfg = LatentConfig()
pop = build_population(2000, cfg, hub.stream("pop"))
mu = np.array([d.mu for d in pop])
classes = np.array([d.capability_class for d in pop])
tau = draw_completion_times(mu, cfg, hub.stream("lat"))

# Deadlines: 3 tiers at 33/66 quantiles + a covering last tier.
cutoffs = tuple(np.append(np.quantile(tau, [0.33, 0.66]), tau.max() * 1.5))
deadlines = RoundDeadlines(round_index=0, cutoffs=cutoffs)

# --- 1. tiering ---
tiers = assign_tiers(tau, deadlines)
check("all assigned (covering last tier => no MISSED)", (tiers == MISSED).sum() == 0)
check("tier indices valid", set(np.unique(tiers)).issubset({0,1,2}))
# Faster devices (lower class) concentrate in earlier tiers.
mean_class_t0 = classes[tiers==0].mean(); mean_class_t2 = classes[tiers==2].mean()
check("earlier tier has faster (lower-class) devices", mean_class_t0 < mean_class_t2,
      f"t0={mean_class_t0:.2f} t2={mean_class_t2:.2f}")

# --- 2. rosters partition the participants ---
rosters = tier_rosters(tiers, num_tiers=3)
total_rostered = sum(len(r) for r in rosters)
check("rosters partition all non-missed", total_rostered == (tiers != MISSED).sum())

# --- 3. dropout winnows roster -> active >= unmask ---
rates = DropoutRates(rho_mask=0.10, rho_unmask=0.05)
outcome = apply_dropout(len(rosters[1]), rates, hub.stream("drop"))
check("active <= roster", outcome.active_count <= outcome.roster_size)
check("unmask <= active", outcome.unmask_count <= outcome.active_count)
# Empirical survival roughly matches 1-rho_mask.
surv = outcome.active_count / max(1, outcome.roster_size)
check("mask survival ~0.90", abs(surv - 0.90) < 0.05, f"got {surv:.3f}")

# --- 4. THRESHOLD INVARIANT: t <= m_min always ---
inv_ok = True
for n_k in [1, 5, 10, 50, 100, 500, 2000]:
    for m_min in [8, 16, 32, 64]:
        t = reconstruction_threshold(n_k, m_min, rates)
        if not safe_coupling_holds(t, m_min):
            inv_ok = False; print(f"      VIOLATION n_k={n_k} m_min={m_min} t={t}")
check("t <= m_min invariant holds across grid", inv_ok)
# Larger tiers don't push t above m_min (the crypto-doc formula bug we avoided).
t_big = reconstruction_threshold(2000, 16, rates)
check("large tier: t clamped to m_min", t_big <= 16, f"t={t_big}")

# --- 5. release gate: below m_min suppresses ---
small = apply_dropout(5, rates, hub.stream("small"))
t_small = reconstruction_threshold(small.active_count, m_min=16, rates=rates)
dec_small = decide_release(small, m_min=16, threshold=t_small)
check("small tier suppressed (below m_min)", not dec_small.released and dec_small.reason=="below_m_min")
# Healthy tier releases.
big = apply_dropout(200, rates, hub.stream("big"))
t_b = reconstruction_threshold(big.active_count, m_min=16, rates=rates)
dec_big = decide_release(big, m_min=16, threshold=t_b)
check("healthy tier releases", dec_big.released, f"reason={dec_big.reason}")

# --- 6. emit_record leaks nothing: suppressed reveals no count/sum ---
rec_sup = emit_record(0, 0, dec_small, deadlines, secure_sum=np.ones(4), release_bucket=0)
check("suppressed record hides count", rec_sup.count is None)
check("suppressed record hides sum", rec_sup.secure_sum is None)
rec_rel = emit_record(0, 1, dec_big, deadlines, secure_sum=np.ones(4), release_bucket=2)
check("released record reveals count", rec_rel.count == dec_big.active_count)

# --- 7. FEDAVG-EQUIVALENCE THEOREM ---
# Build per-device updates; tier sums = sum over active devices; merge should
# equal the plain mean over the union of all active devices.
d_dim = 8
rng_u = hub.stream("updates")
updates = rng_u.normal(size=(2000, d_dim))  # per-device update vectors
# Pick active devices per tier (use roster then a dropout mask), build sums.
contribs = []
union_active_ids = []
for k in range(3):
    roster_ids = rosters[k]
    oc = apply_dropout(len(roster_ids), rates, hub.stream(f"drop.{k}"))
    active_ids = roster_ids[oc.active]  # device ids active in tier k
    if active_ids.size == 0: continue
    S_k = updates[active_ids].sum(axis=0)
    contribs.append(TierContribution(secure_sum=S_k, count=active_ids.size))
    union_active_ids.append(active_ids)
union_ids = np.concatenate(union_active_ids)
merged = size_weighted_merge(contribs)
fedavg = updates[union_ids].mean(axis=0)
check("size-weighted merge == FedAvg-on-participants", np.allclose(merged, fedavg, atol=1e-10),
      f"max diff {np.abs(merged-fedavg).max():.2e}")

# --- 8. weighted_merge with lambda=0 reduces to size-weighted ---
merged_w = weighted_merge(contribs, staleness_lambda=0.0)
check("weighted_merge(lambda=0) == size_weighted", np.allclose(merged_w, merged, atol=1e-10))

# --- 9. server update: no participation leaves model unchanged ---
w0 = np.ones(d_dim)
w1, v1 = apply_server_update(w0, None, lr=0.5)
check("no-participation update is no-op", np.array_equal(w1, w0))
w2, v2 = apply_server_update(w0, merged, lr=0.5)
check("update moves model", not np.array_equal(w2, w0))

print(f"\n{passed} passed, {failed} failed")
sys.exit(1 if failed else 0)
