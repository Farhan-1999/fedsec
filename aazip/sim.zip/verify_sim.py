"""Full-pipeline test: run a multi-round simulation end to end."""
import sys
sys.path.insert(0, "/home/claude/deadline-tiered-fl/src")
import numpy as np
from dtfl.latent import LatentConfig, DriftConfig
from dtfl.sim import Engine, EngineConfig, RoundConfig, snr_diagnostic
from dtfl.transcript import single_bucket, per_tier_bucket
from dtfl.types import TierFlag

passed = failed = 0
def check(name, cond, detail=""):
    global passed, failed
    if cond: print(f"  PASS  {name}"); passed += 1
    else: print(f"  FAIL  {name}  {detail}"); failed += 1

lcfg = LatentConfig()
ecfg = EngineConfig(seed=42, num_devices=1000, num_rounds=50,
                    round_config=RoundConfig(m_min=16))
eng = Engine(ecfg, lcfg)

# Fixed deadlines from a latent probe (experimenter calibration).
cuts = eng.calibrate_fixed_deadlines(quantiles=(0.33, 0.66))
check("calibrated 3 deadlines, increasing", len(cuts)==3 and all(np.diff(cuts)>0), f"{cuts}")

def fixed_policy(r, view): return cuts
out = eng.run(fixed_policy, bucketer=per_tier_bucket)

# --- 1. transcript produced ---
view = out.transcript.view()
check("transcript nonempty", len(view) > 0)
check("covers all rounds", view.rounds()==list(range(50)))
released = view.released()
check("some tiers released", len(released) > 0, f"released={len(released)}")

# --- 2. per-round structure ---
r0 = view.for_round(0)
check("round 0 has <= K records", len(r0) <= 3)
counts0 = view.tier_counts(0)
check("released tiers have integer counts", all(
    (c is None) or (isinstance(c,int) and c>=16) for c in counts0.values()), f"{counts0}")

# --- 3. latent logs separate and aligned ---
check("one latent log per round", len(out.latent_logs)==50)
check("true_classes length N", out.true_classes.shape[0]==1000)
# latent log has ground truth the transcript doesn't
ll0 = out.latent_logs[0]
check("latent log carries active classes", any(c.size>0 for c in ll0.active_classes))
check("latent log carries roster sizes", len(ll0.roster_sizes)==3)

# --- 4. SNR diagnostic from real run ---
mi, _ = snr_diagnostic(out)
check("realized class->tier MI > 0 (signal present)", mi > 0.05, f"MI={mi:.4f}")
print(f"    realized MI = {mi:.4f} nats  (config SNR = {lcfg.signal_to_noise:.2f})")

# --- 5. merge + participation ---
check("participation recorded per round", len(out.participation)==50)
nonzero_part = sum(1 for p in out.participation if p>0)
check("most rounds have participation", nonzero_part > 40, f"{nonzero_part}/50")
merged_rounds = sum(1 for m in out.merged_updates if m is not None)
check("merged update produced when participation>0", merged_rounds==nonzero_part)

# --- 6. virtual clock monotone increasing ---
check("virtual clock increases", all(np.diff(out.virtual_time)>0))

# --- 7. determinism: same seed -> identical transcript ---
eng2 = Engine(EngineConfig(seed=42, num_devices=1000, num_rounds=50,
                           round_config=RoundConfig(m_min=16)), lcfg)
cuts2 = eng2.calibrate_fixed_deadlines(quantiles=(0.33,0.66))
out2 = eng2.run(lambda r,v: cuts2, bucketer=per_tier_bucket)
v2 = out2.transcript.view()
# Compare released counts across both runs.
sig1 = [(r.round_index, r.tier_index, r.flag.value, r.count) for r in view.all()]
sig2 = [(r.round_index, r.tier_index, r.flag.value, r.count) for r in v2.all()]
check("determinism: identical transcript signature", sig1==sig2)

# --- 8. m_min suppression visible: smaller m_min -> more released ---
eng3 = Engine(EngineConfig(seed=42, num_devices=1000, num_rounds=50,
                           round_config=RoundConfig(m_min=200)), lcfg)
cuts3 = eng3.calibrate_fixed_deadlines(quantiles=(0.33,0.66))
out3 = eng3.run(lambda r,v: cuts3, bucketer=per_tier_bucket)
rel_low_mmin = len(view.released())
rel_high_mmin = len(out3.transcript.view().released())
check("higher m_min suppresses more tiers", rel_high_mmin < rel_low_mmin,
      f"m16={rel_low_mmin} releases, m200={rel_high_mmin} releases")

# --- 9. drift run doesn't crash and changes dynamics ---
lcfg_drift = LatentConfig(drift=DriftConfig(regime_shift_prob=0.1, regime_shift_scale=0.3,
                                            device_walk_per_round=0.02))
eng4 = Engine(EngineConfig(seed=42, num_devices=1000, num_rounds=50,
                           round_config=RoundConfig(m_min=16)), lcfg_drift)
cuts4 = eng4.calibrate_fixed_deadlines(quantiles=(0.33,0.66))
out4 = eng4.run(lambda r,v: cuts4, bucketer=per_tier_bucket)
check("drift run completes", len(out4.transcript.view())>0)

print(f"\n{passed} passed, {failed} failed")
sys.exit(1 if failed else 0)
