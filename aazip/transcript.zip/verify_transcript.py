"""Transcript layer test: bucketing, store/view API, serialization round-trip."""
import sys, tempfile, os
sys.path.insert(0, "/home/claude/deadline-tiered-fl/src")
import numpy as np
from dtfl.types import TierRecord, TierFlag, RoundDeadlines
from dtfl.transcript import (
    TranscriptStore, TranscriptView,
    single_bucket, per_tier_bucket, uniform_width_bucketer, quantile_bucketer,
    save_transcript, load_transcript,
)

passed = failed = 0
def check(name, cond, detail=""):
    global passed, failed
    if cond: print(f"  PASS  {name}"); passed += 1
    else: print(f"  FAIL  {name}  {detail}"); failed += 1

deadlines = RoundDeadlines(round_index=0, cutoffs=(1.0, 2.0, 3.0))

# --- 1. bucketers ---
check("single_bucket always 0", single_bucket(0.5, deadlines)==0 and single_bucket(2.9, deadlines)==0)
check("per_tier_bucket maps to tier window",
      per_tier_bucket(0.5, deadlines)==0 and per_tier_bucket(1.5, deadlines)==1 and per_tier_bucket(2.5, deadlines)==2)
ub = uniform_width_bucketer(num_buckets=6, round_budget=3.0)
check("uniform bucketer divides evenly", ub(0.25, deadlines)==0 and ub(1.5, deadlines)==3 and ub(2.9, deadlines)==5)
check("uniform bucketer clamps overflow", ub(99.0, deadlines)==5)
qb = quantile_bucketer(edges=(1.0, 2.0))
check("quantile bucketer", qb(0.5, deadlines)==0 and qb(1.5, deadlines)==1 and qb(2.5, deadlines)==2)

# --- 2. store / view ---
store = TranscriptStore()
recs = [
    TierRecord(0, 0, TierFlag.RELEASED, 50, 0, np.ones(4), deadlines),
    TierRecord(0, 1, TierFlag.SUPPRESSED, None, None, None, deadlines),
    TierRecord(1, 0, TierFlag.RELEASED, 60, 1, np.ones(4)*2, RoundDeadlines(1,(1.,2.,3.))),
]
for r in recs: store.append(r)
view = store.view()
check("view length", len(view)==3)
check("view.released filters", len(view.released())==2)
check("view.for_round", len(view.for_round(0))==2 and len(view.for_round(1))==1)
check("view.for_tier", len(view.for_tier(0))==2)
check("view.rounds", view.rounds()==[0,1])
check("tier_counts: suppressed -> None", view.tier_counts(0)=={0:50, 1:None})
check("release_buckets", view.release_buckets(0)=={0:0, 1:None})
check("signature is visible-only tuple", view.signature(0,0)==(0,0,"released"))

# --- 3. online growth: view sees appends after issuance ---
store.append(TierRecord(2, 0, TierFlag.RELEASED, 70, 0, np.ones(4), RoundDeadlines(2,(1.,2.,3.))))
check("view reflects later appends (online adversary)", len(view)==4 and view.rounds()==[0,1,2])

# --- 4. serialization round-trip: same records back ---
with tempfile.TemporaryDirectory() as td:
    p = os.path.join(td, "transcript.json")
    save_transcript(store.view().all(), p)
    loaded = load_transcript(p)
    check("round-trip count", len(loaded)==4)
    # field-by-field equality on the first record
    a, b = recs[0], loaded[0]
    same = (a.round_index==b.round_index and a.tier_index==b.tier_index and
            a.flag==b.flag and a.count==b.count and a.release_bucket==b.release_bucket and
            np.allclose(a.secure_sum, b.secure_sum) and a.deadlines.cutoffs==b.deadlines.cutoffs)
    check("round-trip fidelity (released record)", same)
    # suppressed record stays Null/None
    bs = loaded[1]
    check("round-trip fidelity (suppressed record)",
          bs.flag==TierFlag.SUPPRESSED and bs.count is None and bs.secure_sum is None)
    # The serialized JSON contains NO latent field names.
    raw = open(p).read()
    bad = [w for w in ("capability","theta","mu","true_","latency","device_id","roster","availability") if w in raw]
    check("serialized transcript has no latent field names", not bad, f"found {bad}")

print(f"\n{passed} passed, {failed} failed")
sys.exit(1 if failed else 0)
