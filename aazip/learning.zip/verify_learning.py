"""Corrected learning test: harder data (real headroom) + clean equivalence check."""
import sys
sys.path.insert(0, "/home/claude/deadline-tiered-fl/src")
import numpy as np
from dtfl.rng import RngHub
from dtfl.latent import LatentConfig
from dtfl.sim import Engine, EngineConfig, RoundConfig
from dtfl.learning import (
    NumpySoftmaxModel, make_synthetic_classification, iid_shard,
    FedTrainConfig, federated_train,
)
from dtfl.protocol import TierContribution, size_weighted_merge

passed = failed = 0
def check(name, cond, detail=""):
    global passed, failed
    if cond: print(f"  PASS  {name}"); passed += 1
    else: print(f"  FAIL  {name}  {detail}"); failed += 1

hub = RngHub(seed=1)
D_IN, C = 20, 5
# HARDER data: lower separation -> real headroom to show learning.
train, val = make_synthetic_classification(6000, D_IN, C, hub.stream("data"), separation=1.0)

# --- FedAvg-equivalence with real deltas: PRECOMPUTE deltas once, reuse them ---
model = NumpySoftmaxModel(D_IN, C, seed=0)
w0 = model.get_params()
shards = iid_shard(train, 30, hub.stream("shard"))
# Compute each client's delta ONCE with a fixed per-client rng, store it.
deltas = []
for i in range(30):
    model.set_params(w0)
    d = model.local_update(shards[i], 1, 0.5, 32, np.random.default_rng(1000+i))
    deltas.append(d)
deltas = np.array(deltas)
# tier sums from the SAME stored deltas
SA = deltas[0:18].sum(axis=0); SB = deltas[18:30].sum(axis=0)
merged = size_weighted_merge([TierContribution(SA,18), TierContribution(SB,12)])
fedavg = deltas.mean(axis=0)
check("FedAvg-equivalence with real deltas", np.allclose(merged, fedavg, atol=1e-12),
      f"max diff {np.abs(merged-fedavg).max():.2e}")

# --- full training on harder data ---
lcfg = LatentConfig()
eng = Engine(EngineConfig(seed=42, num_devices=300, num_rounds=60,
                          round_config=RoundConfig(m_min=8)), lcfg)
cuts = eng.calibrate_fixed_deadlines((0.33, 0.66))
fmodel = NumpySoftmaxModel(D_IN, C, seed=0)
res = federated_train(fmodel, train, val, eng, cuts,
                      FedTrainConfig(local_epochs=1, local_lr=0.3, server_lr=1.0),
                      RoundConfig(m_min=8), base_seed=7)
acc_start, acc_end = res.val_accuracy[0], res.val_accuracy[-1]
acc_max = max(res.val_accuracy)
print(f"    val accuracy: {acc_start:.3f} (r0) -> {acc_end:.3f} (r59), max {acc_max:.3f}")
check("accuracy improves over training", acc_max > acc_start + 0.1, f"{acc_start:.3f} -> max {acc_max:.3f}")
rta = res.round_to_accuracy(0.5); tta = res.time_to_accuracy(0.5)
print(f"    round-to-0.5acc = {rta}, time-to-0.5acc = {tta}")
check("time-to-accuracy computable", rta is not None)

print(f"\n{passed} passed, {failed} failed")
sys.exit(1 if failed else 0)
