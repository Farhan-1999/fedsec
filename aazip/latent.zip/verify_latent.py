"""End-to-end smoke test of the latent package, including the SNR-monotonicity
property that proves the proxy-noise knob works. No pytest (offline)."""
import sys
sys.path.insert(0, "/home/claude/deadline-tiered-fl/src")
import numpy as np
from dtfl.rng import RngHub
from dtfl.latent import (
    LatentConfig, DriftConfig, DriftState,
    build_population, draw_completion_times, class_tier_mutual_information, decompose,
)

passed = failed = 0
def check(name, cond, detail=""):
    global passed, failed
    if cond: print(f"  PASS  {name}"); passed += 1
    else: print(f"  FAIL  {name}  {detail}"); failed += 1

hub = RngHub(seed=12345)
cfg = LatentConfig()

# --- 1. population construction ---
pop = build_population(1000, cfg, hub.stream("latent.population"))
classes = np.array([d.capability_class for d in pop])
mu = np.array([d.mu for d in pop])
check("population size", len(pop) == 1000)
check("classes in range", classes.min() >= 1 and classes.max() <= cfg.num_classes)
# Mixture roughly matches (loose tolerance for n=1000).
frac_c3 = (classes == 3).mean()
check("mixture approx (class 3 ~0.30)", abs(frac_c3 - 0.30) < 0.05, f"got {frac_c3:.3f}")
# Class means increasing: mean mu by class should be monotone increasing.
mean_by_class = [mu[classes == c].mean() for c in range(1, cfg.num_classes + 1)]
check("class means monotone increasing", all(np.diff(mean_by_class) > 0), f"{[f'{m:.2f}' for m in mean_by_class]}")

# --- 2. latency draw ---
tau = draw_completion_times(mu, cfg, hub.stream("latent.latency"))
check("tau positive & finite", np.all(tau > 0) and np.all(np.isfinite(tau)))
check("tau length matches", tau.shape[0] == 1000)
# Faster classes (lower index) should have lower median tau.
med_by_class = [np.median(tau[classes == c]) for c in range(1, cfg.num_classes + 1)]
check("median tau increases with class", all(np.diff(med_by_class) > 0), f"{[f'{m:.2f}' for m in med_by_class]}")

# --- 3. decomposition sums to total ---
dec = decompose(tau)
check("decomposition sums to tau", np.allclose(dec.total, tau))

# --- 4. THE KEY PROPERTY: raising eta lowers class->tier MI monotonically ---
# Build fixed deadlines at class-mean quantiles so tiering is meaningful.
def assign_tiers(tau, deadlines):
    # earliest tier whose deadline tau meets; -1 if misses all.
    t = np.full(tau.shape[0], -1, dtype=np.int64)
    for k, d in enumerate(deadlines):
        unset = (t == -1) & (tau <= d)
        t[unset] = k
    return t

# Deadlines = quantiles of a baseline (low-noise) tau so all etas see same cutoffs.
base_tau = draw_completion_times(mu, cfg.with_eta(0.05), hub.stream("latent.latency"))
deadlines = np.append(np.quantile(base_tau, [0.33, 0.66]), base_tau.max() * 1.5)

etas = [0.05, 0.15, 0.30, 0.50, 0.80]
mis = []
for e in etas:
    c2 = cfg.with_eta(e)
    # fresh stream per eta but same population mu
    tau_e = draw_completion_times(mu, c2, RngHub(seed=999).stream(f"eta.{e}"))
    tiers_e = assign_tiers(tau_e, deadlines)
    mi = class_tier_mutual_information(classes, tiers_e)
    mis.append(mi)
print(f"    SNR by eta: {[f'{cfg.with_eta(e).signal_to_noise:.2f}' for e in etas]}")
print(f"    MI  by eta: {[f'{m:.4f}' for m in mis]}")
# Monotone non-increasing (allow tiny noise tolerance).
mono = all(mis[i] >= mis[i+1] - 0.01 for i in range(len(mis)-1))
check("MI decreases as eta rises (knob works)", mono, f"{[f'{m:.4f}' for m in mis]}")
check("low-eta MI meaningfully > high-eta MI", mis[0] > mis[-1] + 0.05, f"{mis[0]:.4f} vs {mis[-1]:.4f}")

# --- 5. determinism: same seed -> same tau ---
tau_a = draw_completion_times(mu, cfg, RngHub(seed=7).stream("x"))
tau_b = draw_completion_times(mu, cfg, RngHub(seed=7).stream("x"))
check("determinism: same seed same tau", np.array_equal(tau_a, tau_b))

# --- 6. drift no-op when disabled ---
drift_off = DriftState(DriftConfig(), n_devices=1000, rng=hub.stream("latent.drift"))
check("drift offset 0 when disabled", drift_off.step() == 0.0)
check("drift mu unchanged when disabled", np.array_equal(drift_off.apply_device_walk(mu), mu))

# --- 7. drift active changes things ---
drift_on = DriftState(DriftConfig(slow_drift_per_round=0.05, device_walk_per_round=0.02),
                      n_devices=1000, rng=hub.stream("latent.drift2"))
off1 = drift_on.step()
mu2 = drift_on.apply_device_walk(mu)
check("drift active moves global level", off1 != 0.0, f"offset={off1}")
check("drift active moves mu", not np.array_equal(mu2, mu))

print(f"\n{passed} passed, {failed} failed")
sys.exit(1 if failed else 0)
