"""dtfl.metrics: what the paper reports."""
from dtfl.metrics.advantage import AdvantageResult, capability_advantage

__all__ = ["AdvantageResult", "capability_advantage"]
