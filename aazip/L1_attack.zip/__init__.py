"""dtfl.attack: adversaries. Imports transcript/, metrics/, types, rng ONLY."""
from dtfl.attack.base import Adversary
from dtfl.attack.l1_fewshot import L1FewShotAttacker
from dtfl.attack.observation import (
    DeviceObservation,
    ObservationFeaturizer,
    build_observations,
)

__all__ = [
    "Adversary", "L1FewShotAttacker",
    "DeviceObservation", "ObservationFeaturizer", "build_observations",
]
